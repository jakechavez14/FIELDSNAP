import { base44 } from './base44Client';


export const Client = base44.entities.Client;

export const Job = base44.entities.Job;

export const CompanySettings = base44.entities.CompanySettings;

export const Report = base44.entities.Report;



// auth sdk:
export const User = base44.auth;